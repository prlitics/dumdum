## ---- echo=FALSE--------------------------------------------------------------
htmltools::img(src= knitr::image_uri("C:/Users/prlic/Documents/GitHub/dumdum/hexagon.png"), alt = 'dumdum_hexagon', style = 'position:absolute; top:0; right:0; padding:10px;')

## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(dumdum)

