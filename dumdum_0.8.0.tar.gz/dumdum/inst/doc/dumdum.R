## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(include = FALSE)
library(dumdum)

## ----varExample1, echo=TRUE, include=TRUE, eval=FALSE-------------------------
#  dummify(data = iris, var = "Species")

## ----varExample2, echo=TRUE, include=TRUE, eval=FALSE-------------------------
#  dummify(data = iris, var = 5)

## ----reference, echo=TRUE, include=TRUE, eval=FALSE---------------------------
#  dummify(data = iris, var = "Species", reference = T)
#  
#  dummify(data = iris, var = "Species", reference = "setosa")
#  
#  dummify(data = iris, var = "Species", reference = c("setosa", "virginica"))

## ----dumNames, echo=TRUE, include=TRUE, eval=FALSE----------------------------
#  dummify(data = iris, var = "Species", dumNames = c("BristlePointed","BlueFlag","Virginia"))
#  dummify(data = iris, var = "Species", dumNames = c("BristlePointed" = "setosa",
#    "BlueFlag" = "versicolor","Virginia" = "virginica"))

## ----vars, echo=TRUE, include=TRUE, eval=FALSE--------------------------------
#  #install.packages("palmerpenguins")
#  
#  library(palmerpenguins)
#  
#  dummify_across(penguins, c("species","island","sex"))
#  dummify_across(penguins, c(1,2,7))

## ----references, echo=TRUE, include=TRUE, eval=FALSE--------------------------
#  
#  dummify_across(penguins, c("species","island","sex"), reference = TRUE)

